'use client'
import { useState } from 'react'
import { supabase } from '../../lib/supabase'
import { useRouter } from 'next/navigation'

export default function Login() {
  const [email, setEmail] = useState('')
  const [secretId, setSecretId] = useState('')
  const router = useRouter()

  async function login() {
    const { data } = await supabase.from('users').select('*').eq('email', email).eq('secret_id', secretId).single()
    if (data) {
      localStorage.setItem('user', JSON.stringify(data))
      router.push('/dashboard')
    }
  }

  return (
    <div style={{maxWidth: 400, margin: '100px auto', padding: 20}}>
      <h2>Bidder Login</h2>
      <input placeholder="Email" value={email} onChange={e => setEmail(e.target.value)} style={{width: '100%', padding: 10, marginBottom: 10}} />
      <input placeholder="Secret ID" value={secretId} onChange={e => setSecretId(e.target.value)} style={{width: '100%', padding: 10, marginBottom: 10}} />
      <button onClick={login} style={{width: '100%', padding: 10}}>Login</button>
    </div>
  )
}