'use client'
import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'

export default function Dashboard() {
  const [user, setUser] = useState(null)
  const router = useRouter()

  useEffect(() => {
    const u = localStorage.getItem('user')
    if (!u) router.push('/login')
    else setUser(JSON.parse(u))
  }, [])

  if (!user) return <p>Loading...</p>

  return (
    <div style={{maxWidth: 600, margin: '40px auto', padding: 20}}>
      <h2>Welcome {user.email}</h2>
      <p>Your Secret ID: {user.secret_id}</p>
      <p>You’re logged in. Bidding page coming next.</p>
      <button onClick={() => {localStorage.removeItem('user'); router.push('/')}}>Logout</button>
    </div>
  )
}