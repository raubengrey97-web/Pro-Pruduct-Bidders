'use client'
import { useEffect, useState } from 'react'
import { supabase } from '@/lib/supabase'
import Link from 'next/link'

export default function Home() {
  const [products, setProducts] = useState([])
  const [settings, setSettings] = useState(null)

  useEffect(() => {
    loadData()
  }, [])

  async function loadData() {
    const { data: products } = await supabase.from('products').select('*').eq('status', 'active')
    const { data: settings } = await supabase.from('admin_settings').select('*').eq('id', 1).single()
    
    const updated = products?.map(p => ({
      ...p,
      current_min: Math.floor(p.original_price * Math.pow(1.05, p.days_in_system))
    }))
    setProducts(updated)
    setSettings(settings)
  }

  return (
    <div style={{maxWidth: 800, margin: '40px auto', padding: 20}}>
      <h1>Pro Product Bidders</h1>
      <p>Hold Fee: UGX {settings?.hold_fee} | MTN: {settings?.mtn_number} | Airtel: {settings?.airtel_number}</p>
      
      {products?.map(p => (
        <div key={p.id} style={{border: '1px solid #ccc', padding: 20, marginBottom: 20}}>
          <h3>{p.title}</h3>
          {p.photo_url && <img src={p.photo_url} width="100%" style={{maxHeight: 300, objectFit: 'cover'}} />}
          <p>Original: UGX {p.original_price.toLocaleString()}</p>
          <p>Current Min Bid: UGX {p.current_min.toLocaleString()} | Day {p.days_in_system}</p>
          <Link href={`/product/${p.id}`}><button>Place Bid - Pay Hold Fee</button></Link>
        </div>
      ))}
      
      <div style={{marginTop: 40}}>
        <Link href="/login">Login</Link> | <Link href="/signup">Sign Up</Link> | <Link href="/admin">Admin</Link>
      </div>
    </div>
  )
}