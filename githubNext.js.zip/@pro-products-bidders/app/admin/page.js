'use client'
import { useState } from 'react'
import { supabase } from '@/lib/supabase'
import { useRouter } from 'next/navigation'

export default function Admin() {
  const [email, setEmail] = useState('')
  const [title, setTitle] = useState('')
  const [price, setPrice] = useState('')
  const [photo, setPhoto] = useState('')
  const [isAdmin, setIsAdmin] = useState(false)
  const [msg, setMsg] = useState('')
  const router = useRouter()

  async function login() {
    const { data } = await supabase.from('users').select('*').eq('email', email).eq('role', 'admin').single()
    if (data) {
      setIsAdmin(true)
      setMsg('Logged in! Redirecting...')
      setTimeout(() => router.push('/admin'), 1000) // stays on admin page for upload
    } else {
      setMsg('Not an admin')
    }
  }

  async function upload() {
    const { error } = await supabase.from('products').insert([{
      title, original_price: parseInt(price), min_bid: parseInt(price), photo_url: photo, status: 'active', days_in_system: 0
    }])
    setMsg(error ? error.message : 'Uploaded!')
  }

  if (!isAdmin) return (
    <div style={{maxWidth: 400, margin: '100px auto', padding: 20}}>
      <h2>Admin Login</h2>
      <input placeholder="Admin Email" value={email} onChange={e => setEmail(e.target.value)} style={{width: '100%', padding: 10}} />
      <button onClick={login} style={{width: '100%', padding: 10, marginTop: 10}}>Login</button>
      <p>{msg}</p>
    </div>
  )

  return (
    <div style={{maxWidth: 600, margin: '40px auto', padding: 20}}>
      <h2>Admin Dashboard - Upload Product</h2>
      <input placeholder="Title" value={title} onChange={e => setTitle(e.target.value)} style={{width: '100%', padding: 10, marginBottom: 10}} />
      <input placeholder="Original Price UGX" type="number" value={price} onChange={e => setPrice(e.target.value)} style={{width: '100%', padding: 10, marginBottom: 10}} />
      <input placeholder="Photo URL" value={photo} onChange={e => setPhoto(e.target.value)} style={{width: '100%', padding: 10, marginBottom: 10}} />
      <button onClick={upload} style={{width: '100%', padding: 10}}>Upload</button>
      <p>{msg}</p>
    </div>
  )
}