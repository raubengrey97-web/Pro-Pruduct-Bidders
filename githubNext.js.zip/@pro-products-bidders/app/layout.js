export const metadata = {
  title: 'Pro Product Bidders',
  description: 'Bid on products with hold fees',
}

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body style={{margin: 0, fontFamily: 'Arial, sans-serif'}}>{children}</body>
    </html>
  )
}