'use client'
import { useState } from 'react'
import { supabase } from '@/lib/supabase'
import { useRouter } from 'next/navigation'

export default function Signup() {
  const [email, setEmail] = useState('')
  const [phone, setPhone] = useState('')
  const [msg, setMsg] = useState('')
  const router = useRouter()

  async function signup() {
    const secret_id = 'UG-' + Math.random().toString(36).substring(2, 8).toUpperCase()
    const { error } = await supabase.from('users').insert([{ email, phone, secret_id, role: 'bidder' }])
    if (error) {
      setMsg(error.message)
    } else {
      setMsg(`Signed up! Your Secret ID: ${secret_id}. Redirecting to login...`)
      setTimeout(() => router.push('/login'), 2000)
    }
  }

  return (
    <div style={{maxWidth: 400, margin: '100px auto', padding: 20}}>
      <h2>Bidder Signup</h2>
      <input placeholder="Email" value={email} onChange={e => setEmail(e.target.value)} style={{width: '100%', padding: 10, marginBottom: 10}} />
      <input placeholder="Phone" value={phone} onChange={e => setPhone(e.target.value)} style={{width: '100%', padding: 10, marginBottom: 10}} />
      <button onClick={signup} style={{width: '100%', padding: 10}}>Sign Up</button>
      <p>{msg}</p>
    </div>
  )
}